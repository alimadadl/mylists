﻿'use strict';

ExecuteOrDelayUntilScriptLoaded(initializePage, "sp.js");

function initializePage() {
    // skapar ett context objekt som pekar på appwebben
    var appContext = new SP.ClientContext.get_current();

    // TAr fram URL till hostwebben
    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));

    //Skapar ett context objekt som pekar på hostwebben
    var hostContext = new SP.AppContextSite(appContext, 'https://alimadadi.sharepoint.com/sites/pro/');

    //Objekt som pekar på web objektet
    var parentWeb = hostContext.get_web();
    var id = getQueryParameter('id');

    //Objekt som pekar på alla rader i listan
    var listRowCollection = parentWeb.get_lists().getByTitle('myList').getItems("");

    // This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
    $(document).ready(function () {
        getRows();
        
    });



    // This function prepares, loads, and then executes a SharePoint query to get the current users information
    function getRows() {
        appContext.load(listRowCollection);
        appContext.executeQueryAsync(onSuccess, onFail);
    }

    //Tar emot svaret med alla rader i listan
    function onSuccess() {
        var listString = "";
        var listEnumerator = listRowCollection.getEnumerator();

        //Loopar igenom alla rader i listan som finns i en collection
        while (listEnumerator.moveNext()) {

            //Tar fram aktuell rad
            var currentItem = listEnumerator.get_current();

            listString += '<br/><div class="row"><div class="col-md-6 col-xs-12"><div style="color:white"><br/><br/><span style="font-size:20px; font-weight:bold;">' + currentItem.get_item('Title') + '</span>' +
                '<div>' + currentItem.get_item('Price') + '<span> Kr</span></div>' + 
                '<div>' + currentItem.get_item('Location') + '</div>' +
                //'<div>' + currentItem.get_item('Description') + '</div>' +
                '</div></div><div class="col-md-6 col-xs-12"><a id="onm" href="Datail.aspx?id=' + currentItem.get_id() + ' "><img id="home" style="width:300px; height:250px; border:1px solid gray;" src="' + currentItem.get_item('Picture').get_url() + '"/></a></div></div><hr/>';

        }
        
        //Lägger ut i message elementet på sidan
        $('#message').html(listString);
    }



    // This function is executed if the above call fails
    function onFail(sender, args) {
        alert('Failed to get user name. Error:' + args.get_message());
    }

}

//Search Item

function sokClick() {
    $('#detail').hide();
    $('#message').hide();
    $('#search').show();
    //Hämta sökvärdet från webbsidan
    var value = document.getElementById("titel").value;

    //Skapar ett context objekt för appwebben
    var appContext = new SP.ClientContext.get_current();

    //Tar fram URL till hostwebben 
    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));

    //Skapar ett context objekt som pekar på hostwebben
    var hostContext = new SP.AppContextSite(appContext, 'https://alimadadi.sharepoint.com/sites/pro/');

    //Skapar en fråga som gör urval i listan på titeln (om den innehåller sökvillkoret)
    var camlQuery = new SP.CamlQuery();
   
    var query = "<View><Query><Where><Or><Or><Eq><FieldRef Name='Title' /><Value Type='Text'>" + value + "</Value></Eq><Eq><FieldRef Name='Category' /><Value Type='Text'>" + value + "</Value></Eq></Or><Eq><FieldRef Name='Location' /><Value Type='Text'>" + value + "</Value></Eq></Or></Where></Query></View>";
    camlQuery.set_viewXml(query);

    //Kopplar camlfrågan till listan
    var listRowCollection = hostContext.get_web().get_lists().getByTitle('myList').getItems(camlQuery);

    //Laddar upp listan och kör anropet mot SP Servern
    appContext.load(listRowCollection);
    appContext.executeQueryAsync(Onsuccess, OnFail);


    function Onsuccess() {

        var listString = " ";
        var listEnumerator = listRowCollection.getEnumerator();

        //Loopar igenom alla rader i listan som finns i en collection
        while (listEnumerator.moveNext()) {

            //Tar fram aktuell rad
            var currentItem = listEnumerator.get_current();
           
            //Tar fram värdet i en kolumn
            listString += '<br/><div class="row"><div class="col-md-6 col-xs-12"><div style="color:white"><br/><br/><span style="font-size:20px; font-weight:bold;">' + currentItem.get_item('Title') + '</span>'+
                '<div>' + currentItem.get_item('Price') + '<span> Kr<span></div>' +
                '<div>' + currentItem.get_item('Location') + '</div>' +
                //'<div>' + currentItem.get_item('Description') + '</div>' +
                '</div></div><div class="col-md-6 col-xs-12"><a id="onm" href="Datail.aspx?id=' + currentItem.get_id() + ' "><img id="home" style="width:300px; height:250px; border:1px solid gray;" src="' + currentItem.get_item('Picture').get_url() + '"/></a></div></div><hr/>';

        }
        if (listString === " ") {
            alert('Item is not exists.');
        }
        //Lägger ut i message elementet på sidan
        $('#search').html(listString);
    }

    function OnFail() {

        alert("Något gick fel");
    }

} 

//Funktion för att ta fram ett värde 
function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[0].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] === paramToRetrieve)
            return singleParam[1];
    }
}

function getQueryParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}