﻿'use strict';
ExecuteOrDelayUntilScriptLoaded(initializePage, "sp.js");
var user;

function initializePage() {
    // skapar ett context objekt som pekar på appwebben
    var appContext = new SP.ClientContext.get_current();
    user = appContext.get_web().get_currentUser();

    // TAr fram URL till hostwebben
    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));

    //Skapar ett context objekt som pekar på hostwebben
    var hostContext = new SP.AppContextSite(appContext, 'https://alimadadi.sharepoint.com/sites/pro/');

    //Objekt som pekar på web objektet
    var parentWeb = hostContext.get_web();
    var id = getQueryParameter('id');
    
   
    var query = "<View><Query><Where><Eq><FieldRef Name='ID' /><Value Type='Counter'>"+id+"</Value></Eq></Where></Query></View>";
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(query);

    
    //Objekt som pekar på alla rader i listan
    var listRowCollection = parentWeb.get_lists().getByTitle('myList').getItems(camlQuery);

    // This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
    $(document).ready(function () {
        getRows();

    });


    // This function prepares, loads, and then executes a SharePoint query to get the current users information
    function getRows() {
        appContext.load(listRowCollection);
        appContext.load(user);
        appContext.executeQueryAsync(onSuccess, onFail);
    }

    //Tar emot svaret med alla rader i listan
    function onSuccess() {
        var listString = "";
        var listEnumerator = listRowCollection.getEnumerator();
        
        while (listEnumerator.moveNext()) {
            var Edit;
            //Tar fram aktuell rad
            var currentItem = listEnumerator.get_current();
            //var user = currentItem.get_item('Author').get_lookupValue();
            var user1 = user.get_title();
            var userName = currentItem.get_item('Author').get_lookupValue();
            if (user1 === userName) {
                listString+='<div style="margin:20px"><button type="button" id="update" class="btn btn-primary" onclick="updateListItem()">Edit</button>';
                listString +='<button type="button" style="margin-left:20px" class="btn btn-primary" onclick="DeleteItem(id)">Delete</button></div>';
            }
                
                listString += 
                    '<br/><div class="row"><div class="col-md-5 col-xs-12"><div style="color:white"><br/><br/><span style="font-size:20px; font-weight:bold; margin-left:30px;">' + currentItem.get_item('Title') + '</span>' +
                    '<div style="margin-left:30px;">' + currentItem.get_item('Price') + '<span> Kr</span></div>' +
                    '<div style="margin-left:30px;">' + currentItem.get_item('Location') + '</div>' +
                    '<div style="margin-left:30px;">' + currentItem.get_item('Description') + '</div>' +
                    '<div style="margin-top:250px; margin-left:30px"><span class="btn btn-primary w-50 p-2 rounded border border-secondary bg-primary" >' + currentItem.get_item('Mobile') + '</span>' +
                    '<div style="margin-top:20px"><button type="button" class="btn btn-primary w-50 p-2 rounded border border-secondary bg-primary" onclick="outlook()">' + currentItem.get_item('Email') + '</button></div></div > ' +  
                    '</div></div><div class="col-md-5 col-xs-12"><img id="b" style="width:600px; height:500px; border:1px solid gray;" src="' + currentItem.get_item('Picture').get_url() + '"/></div></div><hr/>';
            
        }

        //Lägger ut i message elementet på sidan
        $('#detail').html(listString);

        //console.log(listEnumerator);

   
    }


    // This function is executed if the above call fails
    function onFail(sender, args) {
        alert('Failed to get user name. Error:' + args.get_message());
    }

    function getQueryParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }
}


function outlook() {
    window.location.href = "mailto:user@example.com?subject=Subject&body=message%20goes%20here";
}

/////////////////////////////////////////////////////////

function DeleteItem(id) {
    //Skapar ett context objekt mot appwebben
    var appContext = new SP.ClientContext.get_current();
     id = getQueryParameter('id');
    //Skapar ett context objekt mot hostwebben för att komma åt listan som ligger där
    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var hostContext = new SP.AppContextSite(appContext, 'https://alimadadi.sharepoint.com/sites/pro/');
    var list = hostContext.get_web().get_lists().getByTitle('myList');

    var ListItem = list.getItemById(parseInt(id));

    ListItem.deleteObject();
    appContext.load(ListItem);
    appContext.executeQueryAsync(onSuccess, onFaill);
    function onSuccess() {

        alert("Something is wrong");
    }

    function onFaill() {

        alert("Item deleted");
        window.location.replace("https://alimadadi-763521cd5f1e0a.sharepoint.com/sites/pro/myList/Pages/Default.aspx?SPHostUrl=https%3A%2F%2Falimadadi%2Esharepoint%2Ecom%2Fsites%2Fpro&SPLanguage=en-US&SPClientTag=0&SPProductNumber=16%2E0%2E8901%2E1212&SPAppWebUrl=https%3A%2F%2Falimadadi-763521cd5f1e0a%2Esharepoint%2Ecom%2Fsites%2Fpro%2FmyList");
    }
}
/////////////////////////////////////////////////////////

function updateListItem() {
    var x = document.getElementById("modal");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }

    document.querySelector('#modal').scrollIntoView({
        behavior: 'smooth'
    });

    var newName = document.getElementById("productName").value;
    var price = document.getElementById("price").value;
    var description = document.getElementById("description").value;
    var loc = document.getElementById("place").value;
    var pic = document.getElementById("imageUrl").value;
    var category = document.getElementById("category").value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;
    
    
    

    var appContext = new SP.ClientContext.get_current();
    //var searchText = document.getElementById("search").value;
    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var hostContext = new SP.AppContextSite(appContext, 'https://alimadadi.sharepoint.com/sites/pro/');
    var id = getQueryParameter('id');

    var camlQuery = new SP.CamlQuery();
    var query = "<View><Query><Where><Eq><FieldRef Name='ID' /><Value Type='Counter'> "
        + id + "</Value></Eq ></Where ></Query > <ViewFields><FieldRef Name='Title' /><FieldRef Name='Text' /><FieldRef Name='Price' /><FieldRef Name='Description' /><FieldRef Name='Location' /><FieldRef Name='Picture' /><FieldRef Name='Category' /><FieldRef Name='Email' /><FieldRef Name='Mobile' /></ViewFields> <QueryOptions /></View > ";

    camlQuery.set_viewXml(query);
    var listRowCollection = hostContext.get_web().get_lists().getByTitle('myList').getItems(camlQuery);

    //Laddar upp listan och kör anropet mot SP Servern
    appContext.load(listRowCollection);
    appContext.executeQueryAsync(onSuccess, onFail);

    function onSuccess() {
        var listEnumerator = listRowCollection.getEnumerator();
        //Loopar igenom alla rader i listan som finns i en collection
        while (listEnumerator.moveNext()) {
            //Tar fram aktuell rad
            var currentItem = listEnumerator.get_current();
            var name = currentItem.get_item('Title');
            var price = currentItem.get_item('Price');
            var description = currentItem.get_item('Description');
            var loc = currentItem.get_item('Location');
            var pic = currentItem.get_item('Picture').get_url();
            var category = currentItem.get_item('Category');
            var email = currentItem.get_item('Email');
            var mobile = currentItem.get_item('Mobile');
            
            
            
            $('#productName').val(name);
            $('#price').val(price);
            $('#description').val(description);
            $('#place').val(loc);
            $('#imageUrl').val(pic);
            $('#category').val(category);
            $('#email').val(email);
            $('#mobile').val(mobile);
            
            
            
        }



        //window.location.replace("https://alimadadi-763521cd5f1e03.sharepoint.com/sites/pro/myList/Pages/Default.aspx?SPHostUrl=https%3A%2F%2Falimadadi%2Esharepoint%2Ecom%2Fsites%2Fpro&SPLanguage=en-US&SPClientTag=0&SPProductNumber=16%2E0%2E8824%2E1211&SPAppWebUrl=https%3A%2F%2Falimadadi-763521cd5f1e03%2Esharepoint%2Ecom%2Fsites%2Fpro%2FmyList");
    }

    function onFail(sender, args) {
        alert('Failed to get user name. Error:' + args.get_message());
    }



}

////////////////////////////////////////////////////////
function Save() {
    var clientContext = new SP.ClientContext.get_current();
    var name = document.getElementById("productName").value;
    var price = document.getElementById("price").value;
    var description = document.getElementById("description").value;
    var loc = document.getElementById("place").value;
    var pic = document.getElementById("imageUrl").value;
    var category = document.getElementById("category").value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;

    var id = getQueryParameter('id');

    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var hostContext = new SP.AppContextSite(clientContext, 'https://alimadadi.sharepoint.com/sites/pro/');
    var list = hostContext.get_web().get_lists().getByTitle('myList'); 

    if ($('#productName').val() === "") {
        alert('Name is require');
        $('#productName').focus();
        return false;
    }
    if ($('#price').val() === "") {
        alert('Price is require');
        $('#price').focus();
        return false;
    }
    if ($('#description').val() === "") {
        alert('description is require');
        $('#description').focus();
        return false;
    }
    if ($('#place').val() === "") {
        alert('Location is require');
        $('#place').focus();
        return false;
    }
    if ($('#imageUrl').val() === "") {
        alert('Url for iamge is require');
        $('#imageUrl').focus();
        return false;
    }
    if ($('#email').val() === "") {
        alert('Email is require');
        $('#email').focus();
        return false;
    }
    if ($('#mobile').val() === "" || $('#mobile').val().length < 10 || $('#mobile').val().length > 10) {
        alert('Phone number is require or wrong format plz enter 10 digits number');
        $('#mobile').focus();
        return false;
    }
    
    var newItem = list.getItemById(id);

    newItem.set_item('Title', name);
    newItem.set_item('Price', price);
    newItem.set_item('Description', description);
    newItem.set_item('Location', loc);
    newItem.set_item('Picture', pic);
    newItem.set_item('Category', category);
    newItem.set_item('Email', email);
    newItem.set_item('Mobile', mobile);
    newItem.update();

    clientContext.load(newItem);
    clientContext.executeQueryAsync(onSuccess, onFail);
}

function onSuccess() {
    
    
        alert('Item updated');
        window.location.replace("https://alimadadi-763521cd5f1e0a.sharepoint.com/sites/pro/myList/Pages/Default.aspx?SPHostUrl=https%3A%2F%2Falimadadi%2Esharepoint%2Ecom%2Fsites%2Fpro&SPLanguage=en-US&SPClientTag=0&SPProductNumber=16%2E0%2E8901%2E1212&SPAppWebUrl=https%3A%2F%2Falimadadi-763521cd5f1e0a%2Esharepoint%2Ecom%2Fsites%2Fpro%2FmyList");
    
}


function onFail() {
    alert('Something is wrong');
}





function getQueryParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] === paramToRetrieve)
            return singleParam[1];
    }
}

