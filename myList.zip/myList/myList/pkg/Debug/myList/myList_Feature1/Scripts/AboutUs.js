﻿$(document).ready(function () {
    $('#menu').show();
});