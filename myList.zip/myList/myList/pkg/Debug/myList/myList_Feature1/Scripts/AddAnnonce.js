﻿'use strict';

ExecuteOrDelayUntilScriptLoaded(myFunc, "sp.js");
var user;
var userName;
function myFunc() {
    var context = SP.ClientContext.get_current();
    user = context.get_web().get_currentUser();

    //// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
    $(document).ready(function () {
        context.load(user);
        context.executeQueryAsync(onSuccess, onFail);
    });

    function onSuccess() {
        userName = user.get_title();
    }

    function onFail(sender, args) {
        alert('Failed to get user name. Error:' + args.get_message());
    }
}


var newItem = "";
function SaveAnnonce() {
    var clientContext = new SP.ClientContext.get_current();
    //var user = clientContext.get_web().get_currentUser();
    clientContext.load(user);
    var name = document.getElementById("productName").value;
    var price = document.getElementById("price").value;
    var description = document.getElementById("description").value;
    var loc = document.getElementById("place").value;
    var pic = document.getElementById("imageUrl").value;
    var category = document.getElementById("category").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;

    //var userName = user.get_title();

    var hostURL = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var hostContext = new SP.AppContextSite(clientContext, 'https://alimadadi.sharepoint.com/sites/pro/');
    var list = hostContext.get_web().get_lists().getByTitle('myList');

    if ($('#productName').val() === "") {
        alert('Name is require');
        $('#productName').focus();
        return false;
    }
    if ($('#price').val() === "") {
        alert('Price is require');
        $('#price').focus();
        return false;
    }
    if ($('#description').val() === "") {
        alert('description is require');
        $('#description').focus();
        return false;
    }
    if ($('#place').val() === "") {
        alert('Location is require');
        $('#place').focus();
        return false;
    }
    if ($('#imageUrl').val() === "") {
        alert('Url for iamge is require');
        $('#imageUrl').focus();
        return false;
    }
    if ($('#email').val() === "") {
        alert('Email is require');
        $('#email').focus();
        return false;
    }
    if ($('#mobile').val() === "" || $('#mobile').val().length < 10 || $('#mobile').val().length > 10) {
        alert('Phone number is require or wrong format plz enter 10 digits number');
        $('#mobile').focus();
        return false;
    }

    var creationInfo = new SP.ListItemCreationInformation();
    newItem = list.addItem(creationInfo);

    newItem.set_item('Title', name);
    newItem.set_item('Price', price);
    newItem.set_item('Description', description);
    newItem.set_item('Location', loc);
    newItem.set_item('Picture', pic);
    newItem.set_item('Category', category);
    //newItem.set_item('UserName', userName);
    newItem.set_item('Mobile', mobile);
    newItem.set_item('Email', email);
    newItem.set_item('UserName', userName);
    newItem.update();

    //clientContext.load(newItem);
    clientContext.executeQueryAsync(onSuccess, onFail);
}

function onSuccess() {
   
    
    alert('Item added to list');
        window.location.replace("https://alimadadi-763521cd5f1e0b.sharepoint.com/sites/pro/myList/Pages/Default.aspx?SPHostUrl=https%3A%2F%2Falimadadi%2Esharepoint%2Ecom%2Fsites%2Fpro&SPLanguage=en-US&SPClientTag=0&SPProductNumber=16%2E0%2E8901%2E1212&SPAppWebUrl=https%3A%2F%2Falimadadi-763521cd5f1e0b%2Esharepoint%2Ecom%2Fsites%2Fpro%2FmyList");
        
}

function onFail() {
    alert('Something is wrong');
}

function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[0].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] === paramToRetrieve)
            return singleParam[1];
    }
}